#include <iostream>
using namespace std;
#include "Word.h"
// ANSI escape codes for colors
char KeepPlaying();
int main()
{
    Word w;
    w.PlayGame();
    return 0;
}
