//
// Created by Jake Power on 2/23/24.
//
#include "Word.h"
#include <ctime>
#include <cstdlib>		// for rand(), srand()
#include <string>
#include <fstream>
#include <stdlib.h>
#define RESET   "\033[0m"
#define GREEN   "\033[32m"
#define YELLOW  "\033[33m"
using namespace std;
Word::Word( ) {
    word = " ";
    dailyWord = " ";
    sz= maxSize =current = 0;
    nameList = new Player[1];
    //scoreList = new int[1];
}
bool Word::openFile(const char * name)
{
    ifstream file;
    file.open(name);
    if(!file)
    {
        return false;
    }
    else
        return true;
}
string Word::setDailyWord()
{
    Randomize();
    string daily;
    while(openFile("Five-Letter words"))
    {
        ifstream file("Five-Letter words");
        int r = rand() % 2314;
        for(size_t i = 0;i<r;i++)
        {
            getline(file,daily);
        }
        file.close();
        return daily;
    }
    return " ";

}
string Word::getDailyWord()
{
   dailyWord= setDailyWord();
   return dailyWord;
}
string Word::setWord(string s)
{
    //cin.clear();
    while(!getValidWord(s))
    {
        //cin.get();
        cout<<"Please enter a valid 5 letter word\n";
        cin>>s;
    }
    word = s;
    return word;
}
string Word::getWord()
{
    return word;
}
bool Word::Compare()
{
    if(word==dailyWord)
    {
        return true;
    }
    return false;
}
void Word::PlayGame()
{

    Player p;
    string s,temp,name;
    //int count,index = 0;
    int index = 0;
    cout<<"Welcome to my Wordle game!\n";
    char ANS;
    getDailyWord();
    do {
        //sz = 1;
        //guessedLetters = new char [sz];
        word = " ";
        int count =0;
        if(index != 0)
        {
            for(int i =0;i<20;i++)
            {
                cout<<endl;
            }
        }
        changeUsername(index);
        while (count != 6 && !Compare()) {
            count++;
            cin.clear();
            cout << "\nPlease enter guess #" << count << ", press 1 to display the rules, or press 2 to display your total score \n";
            cin >> s;
            temp = toLower(s);
            while (temp == "1")
            {
                DisplayRules();
                if (count > 1) {
                    cout << "\nYour guess for guess #" << count - 1 << " is: ";
                    lookForLetter();
                }
                cout << "\nPlease enter guess #" << count << endl;
                cin >> s;
                temp = toLower(s);
            }
            while (temp == "2")
            {
                cout<<"Your total score is "<<nameList[current].score<<endl;
                if (count > 1) {
                    cout << "\nYour guess for guess #" << count - 1 << " is: ";
                    lookForLetter();
                }
                cout << "\nPlease enter guess #" << count << endl;
                cin >> s;
                temp = toLower(s);
            }
            /*while (temp == "3")
            {
                cout<<"The letters you have guessed so far are: ";
                for(int i=0;i<sz;i++)
                {
                    cout<<guessedLetters[i];
                }
                cout<<endl;
                if (count > 1) {
                    cout << "\nYour guess for guess #" << count - 1 << " is: ";
                    lookForLetter();
                }
                cout << "\nPlease enter guess #" << count << endl;
                cin >> s;
                temp = toLower(s);
            }*/
            setWord(temp);
            lookForLetter();

        }
        if (Compare()) {
            cout << "\nYou got it! ";
        } else {
            cout << "\nUnfortunately, that is all of your guesses. \n";
            cout << "The word is " << dailyWord << endl;
            count = 7;
        }

        nameList[current].score += nameList[current].calculateScore(count);
        cout<<"\nWould you like to play again(y/n)? ";
        ANS = KeepPlaying();
        index++;
    }while( ANS !='n');
    cout<<"\nThanks for playing ";
    exportScore();
    cout<<"Check the HighScoresSheet.txt to view your scores!"<<endl;
}
void Word::lookForLetter() {
    //word = hello, daily word =
    //make an array that checks daily words against valid words
    bool found;
    bool correct[5];
    for (int i = 0; i < word.length(); i++) {
        correct[i] = false;
        if (word[i] == dailyWord[i]) {
            correct[i] = true;
        }
    }
    for (int i = 0; i <word.length(); i++) //i need to code for double letters, meaning it only populates as correct if there are multiple letters in the daily word
        //ex daily word is hello, jello
    {
        //guessedLetters[sz] = word[i];
        //sz++;
        if (word == dailyWord) {
            cout << GREEN << word[i] << RESET;
            found = true;
        } else {
            if (word[i] == dailyWord[i]) {
                cout << GREEN << word[i] << RESET;
                found = true;
            } else {
                for (int j = 0; j < dailyWord.length(); j++) {
                    found = false;
                    if (word[i] == dailyWord[j] && !correct[j]) {
                        found = true;
                        cout << YELLOW << word[i] << RESET;
                        correct[i] = false;

                        /*if (i == j) {
                            cout << GREEN << word[i] << RESET;
                        } else {
                            cout << YELLOW << word[i] << RESET;*/


                        break;
                    }
                }

            }
            if (!found) {
                cout << word[i];
            }

        }
        /*for(int k = 0;k<=sz;k++)
        {
            int temp =0;
            if(guessedLetters[k]!=word[temp])
            {
            sz++;
            cout<<sz;
            guessedLetters[k]= word[temp];
            cout<<guessedLetters[k];
            }
            temp++;
        }
        int count = 0;
        for(int i = 0;i<sz;i++)
        {
            for(int j=0;j<sz;j++)
            {
                if(guessedLetters[i] == guessedLetters[j])
                {
                    count++;
                    i = j;
                    guessedLetters[i] = guessedLetters[j];
                    guessedLetters[j] = ' ';
                }
            }
        }
        sz -=count;
        for(int i = 0;i<sz;i++)
        {
            cout<<guessedLetters[i];
        }*/
    }
}